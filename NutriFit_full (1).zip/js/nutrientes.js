
document.addEventListener("DOMContentLoaded", ()=>{
  const data = localStorage.getItem("alimentoSeleccionado");
  if(data){
    const a = JSON.parse(data);
    document.getElementById("nombre").value=a.nombre;
    document.getElementById("calorias").value=a.calorias;
    document.getElementById("proteinas").value=a.proteinas;
    document.getElementById("carbohidratos").value=a.carbohidratos;
    document.getElementById("grasas").value=a.grasas;
  }
});
